let imgBtn = document.querySelector("img");
let songNameBtn = document.querySelector("h4");
let durationBtn = document.querySelector("#duration");
let volumeBtn = document.querySelector("#volume");
let previousBtn = document.querySelector(".fa-backward-step");
let playBtn = document.querySelector(".fa-play");
let pauseBtn = document.querySelector(".fa-pause");
let NextBtn = document.querySelector(".fa-forward-step");
let favBtn = document.querySelector(".fa-heart");
let audioPlayer = document.querySelector("audio");
pauseBtn.style.display = "none";


audioPlayer.style.display = 'none'


let storage = [
  {
    name: "Shiv Tandav Stotram",
    songImage: "./img/shiv tandav.jpg",
    songSource: "./music/_Shiv Tandav Stotram(PagalWorld.com.cm).mp3",
  },
  {
    name: "heeriye",
    songImage: "./img/heeriye.jpg",
    songSource: "./music/_Heeriye(PagalWorld.com.cm).mp3",
  },
  {
    name: "kahani suno",
    songImage: "./img/kahani suno.jpg",
    songSource: "./music/Kahani Suno(PagalWorld.com.cm).mp3",
  },
  {
    name: "shiv spirit",
    songImage: "./img/shiv spirit.jpg",
    songSource: "./music/Shiva Spirit(PagalWorld.com.cm).mp3",
  },
  {
    name: "Shiv Panchakshara Stotram",
    songImage: "./img/shiv stotram.jpg",
    songSource: "./music/Shiva Panchakshara Stotram(PagalWorld.com.cm).mp3",
  },
];

let index = 0;
let realTime = 0;

function playFun() {
  imgBtn.src = storage[index].songImage;
  audioPlayer.src = storage[index].songSource;
  songNameBtn.innerHTML = storage[index].name;
  audioPlayer.src = storage[index].songSource;
  audioPlayer.currentTime = realTime;
  audioPlayer.play();

  setInterval(() => {
    durationBtn.value = (audioPlayer.currentTime / audioPlayer.duration) * 100;
  }, 1000);

  playBtn.style.display = "none";
  pauseBtn.style.display = "block";
}

playBtn.addEventListener("click", playFun);

pauseBtn.addEventListener("click", () => {
  audioPlayer.pause();
  realTime = audioPlayer.currentTime;
  playBtn.style.display = "block";
  pauseBtn.style.display = "none";
});

NextBtn.addEventListener("click", () => {
  index = (index + 1) % storage.length;
  realTime = 0;

  playFun();
});
previousBtn.addEventListener("click", () => {
  index = (index - 1 + storage.length) % storage.length;
  realTime = 0;
  playFun();
});

durationBtn.addEventListener("input", () => {
  audioPlayer.currentTime = (audioPlayer.duration * durationBtn.value) / 100;
});
audioPlayer.addEventListener("ended", () => {
  index = (index + 1) % storage.length;
  realTime = 0;

  playFun();
});
volumeBtn.addEventListener('input',()=>{
  audioPlayer.volume = volumeBtn.value / 100
})

// let musicList = document.querySelector("#musicList");
// storage.forEach((ele, i) => {
//     musicList.innerHTML += `<p> ${i + 1}. ${ele.name} </p>`;
// });
// let playSong = document.querySelectorAll("#musicList p" );
// console.log(playSong)

// playSong.addEventListener('click',(e)=>{

// })
